import json
import boto3

# Initialize the S3 client
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    try:
        # Extract data from the event
        event_data = event['data']

        # Process the data (customize this based on your requirements)
        processed_data = process_data(event_data)

        # Interact with AWS services (e.g., write to S3)
        save_data_to_s3(processed_data)

        # Generate output
        response = {
            'statusCode': 200,
            'body': json.dumps({'message': 'Lambda function executed successfully'}),
            'processed_data': processed_data
        }
    except Exception as e:
        # Handle errors
        response = {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

    return response

def process_data(data):
    # Perform data processing (customize this based on your requirements)
    processed_data = data.upper()  # Example: Convert data to uppercase
    return processed_data

def save_data_to_s3(data):
    # Write data to an S3 bucket
    bucket_name = 'your-bucket-name'  # Replace with your S3 bucket name
    object_key = 'your/object/key.txt'  # Replace with the desired object key
    s3_client.put_object(Bucket=bucket_name, Key=object_key, Body=data.encode('utf-8'))
